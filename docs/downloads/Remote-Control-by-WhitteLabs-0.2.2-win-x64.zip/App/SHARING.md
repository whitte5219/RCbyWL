# Share Remote Control by WhitteLabs

The `Remote-Control-by-WhitteLabs-0.2.2-win-x64.zip` release contains the ready-to-run **App** folder. Source code is packaged separately. Windows 10 / 11 x64 is supported; the .NET runtime and sensor provider are included.

## Send it to another person or PC

1. Send the release ZIP by a file-sharing service, USB drive or local network copy. Alternatively, copy the complete `App` folder.
2. The recipient extracts the whole ZIP to a permanent folder.
3. Open `App\RemoteControl.exe` or double-click `Open-Remote-Control.cmd`.
4. To use it only as a controller, no installation is required. Choose **Add computer** when ready to pair.
5. To make that PC accessible, choose **Set up this PC > Install / update access**. Approve Windows elevation and wait for the result in the app. `Install-Remote-Access.cmd` is an alternative double-click launcher for the same setup.
6. Generate an invitation on the remote PC. Paste it into **Add computer** on the main/controller PC, check the address, then add it.

There is an included setup script and an in-app setup button; there is currently no MSI or separate `Setup.exe` wizard.

## What setup installs

- The app is copied to `C:\Program Files\WhitteLabs\RemoteControl`.
- A Windows service starts management access at boot.
- A desktop companion starts when the installation user signs in.
- Inbound rules are created for TCP 48170 on Private/Domain profiles and UDP 48171 discovery on the local subnet.
- Each PC generates its own identity. Generating an invitation does not by itself create a connection; a controller must use that invitation to pair.

## What to send

Keep **all** files in `App` together, including DLLs, runtime files, `sensors`, `Setup.ps1` and notices. Sending only `RemoteControl.exe` will not work.

Send the clean release ZIP, not a copy of the Windows configuration folders. The release does not include controller credentials, paired-device lists, temporary invitations or agent identities. The source ZIP is optional and is not needed to use the app.

An invitation permits full management access. Each recipient can set up and pair their own PCs independently; their installations are not automatically connected to yours. Do not share an invitation unless you intend that controller to have access.

## Connecting away from home

Sharing and installing the app does not automatically connect separate home networks. Both sides still need a reachable network path: your own routed VPN, reachable IPv6, or explicitly configured TCP forwarding. No external relay, API key or automatic CGNAT bypass is included. LAN discovery only works within the local subnet.

## Updating an existing installation

1. Close the app on the PC being updated; finish active transfers first.
2. Extract the new App folder to a separate folder and open it.
3. On a PC with remote access installed, choose **Set up this PC > Install / update access**. Setup replaces the installed service and companion files while retaining the device identity and pairings.
4. Reopen the updated controller from its permanent location. If its path changed, replace any shortcuts and toggle **Open with Windows** off/on to update that path.

For this project's local build, the `dist\RemoteControl\RemoteControl.exe` location stays the same, so the existing desktop shortcut continues to point to the new build after the app is closed and reopened.

## Window size and shortcuts

Drag a window edge to resize, use the title-bar maximize button, or press F11 for full screen (Escape restores it). The initial window fits your display and Windows scaling. Small windows provide scrolling so controls stay accessible. Click the small **Create desktop shortcut** icon beside **Open with Windows** in the sidebar to add RCbyWL to your Windows desktop, including redirected OneDrive desktops. Keep the app folder at that location afterward.

The custom title bar stays above the scrolling content. Drag it to move the app, double-click it to maximize or restore, and use its top-right minimize, maximize and close buttons. Startup bounds are clamped to the current monitor work area, including Windows display scaling and monitors with negative coordinates.
