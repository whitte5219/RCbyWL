# RCbyWL 0.2.7 protection

Protection primarily protects the controller (main PC) from an infected connected side PC. Enable Advanced protection on the main PC. It is a defense layer, not antivirus or a guarantee that malware cannot spread through Windows or other software.

Basic protection is always active and preserves the existing features and 5/10/15/30/45/60 FPS options. Incoming HTTP replies, JSON depth/strings, JPEG dimensions, video packet sizes, stable stream formats and decoded buffers are bounded. Per-PC TLS identities stay pinned; redirects, cookies and proxies stay off. Side-PC replies cannot change local protection settings or replace a paired certificate.

Downloads require a local Save dialog. A remote name cannot select a local path or hide its extension using bidirectional controls. Downloads cannot replace RCbyWL code or credentials, Windows/startup files, follow local links or target network paths. Mark-of-the-Web is attached before the final rename. Downloads are never opened automatically. A downloaded file may still contain malware: do not open files you do not trust.

Advanced protection includes Basic protection. It disables transfers, program/process operations, power/lid commands, wake relays, LAN scanning and automatic address recovery. Desktop viewing and mouse/keyboard control, reconnect input, Task Manager, fullscreen, stats, pairing and shared plain-text notes remain available.

The Advanced desktop uses uncompressed BGR32 pixel frames at up to 1280 x 720 and 5/10/15 FPS. It never sends incoming frame bytes into JPEG, PNG or H.264 decoders. A fixed magic value, dimensions, exact byte count and exact packet length are checked before copying pixels. Invalid or compressed data is rejected. This uses more network bandwidth and reduces quality/FPS compared with Basic mode. Three consecutive unsafe frames stop the viewer; close/reopen after resolving the cause. Both PCs need v0.2.7, and the side PC needs Install / update access once. Pairing is preserved. Old side-PC services are rejected in Advanced mode with an upgrade message, without falling back to a compressed decoder.

The server's installed access permissions are otherwise unchanged. The setting does not reconfigure Windows Firewall or uninstall an existing local host service. An infected side PC can still show deceptive screen content. Keep Windows and the app runtime updated.

## Bundled runtime

The previous bundle used .NET 8.0.11. The required release runtime is 8.0.33 (Microsoft's October 2026 security patch). This session could not download it. Finish-Protection-Update.ps1 fetches the patched runtime from normal PowerShell, rebuilds, checks the protection protocol, updates the existing shortcut's app and prepares the website ZIP. Release packaging refuses the old runtime. An installed Windows runtime does not update the runtime in a self-contained app. A development build using the previous runtime is not the patched release.
