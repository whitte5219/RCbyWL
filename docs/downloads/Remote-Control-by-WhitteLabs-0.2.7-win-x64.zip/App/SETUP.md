# Remote Control by WhitteLabs

Version 0.2.6 · Windows 10 / 11 x64 · personal test build

## Getting started

1. Extract the complete ZIP. Keep every file in the `App` folder together.
2. On your main PC, open `App\RemoteControl.exe`.
3. Copy the same App folder to each remote PC. Open the app there and choose **Set up this PC → Install / update access**. Approve Windows elevation. The app reports the setup result. If setup fails, the error stays visible. You can also run Install-Remote-Access.cmd to see the result in a console.
4. On the remote PC, click **Generate pairing code**, then **Copy invitation** for manual pairing. LAN pairing can use just the code and a certificate comparison.
5. On the main PC, click **Add computer**. Paste the invitation and enter the remote PC's IPv4 address. The invitation includes a pinned TLS certificate, expires in five minutes, and works once.
6. Select the paired PC. Test telemetry, files, processes, then **Open desktop**.

There are no subscriptions, external accounts, API keys, analytics, or external servers. Keys and credentials are created and handled internally. Possession of an invitation permits full management: copy it directly between your own PCs.

## Startup and installation

The controller is portable. Its **Start controller with Windows** checkbox is optional and applies to your Windows account; keep the app at the same path if enabled.

Remote-PC setup installs files under `C:\Program Files\WhitteLabs\RemoteControl`, stores its identity under `%ProgramData%\WhitteLabs\RemoteControl`, and creates an automatic LocalSystem Windows service. This grants approved controllers system-level file and process management. A separate tray companion starts when the account that opened setup signs in. The in-app button and CMD launcher preserve that account when Windows elevation uses a different administrator's credentials.

The service starts before login. Desktop access becomes available after that user signs in. The tray menu can pause desktop viewing and input or exit the companion. Pausing desktop access does not disable the management service; revoke controllers or uninstall remote-PC mode to remove management access.

**Uninstall remote-PC mode** removes the service, scheduled companion task, and app firewall rules. It retains installed files and identity data so reinstall preserves pairing. To reset the identity completely, first uninstall, close the app, then manually remove its ProgramData folder locally; every controller must then pair again.

## LAN and WLAN

Default management port: **TCP 48170 (TLS)**. Local discovery: **UDP 48171**. Setup adds inbound rules only on Private and Domain network profiles. Discovery stays on the local subnet. Guest Wi-Fi, client isolation, Public profiles, firewalls, and VLAN routing can block access. Manual IP pairing works when discovery broadcasts are blocked but TCP is reachable.

## WAN

The app accepts a reachable hostname, IPv4, or IPv6 address. Configure a network path yourself: a routed private VPN you host, reachable IPv6 with restricted firewall access, or an explicit TCP port-forward. Set the endpoint in **Connection settings**. Certificate pinning remains active regardless of address changes. A public forwarded port may differ from the agent port: use the TCP port field after pairing. Initial pairing can be done on LAN first; For WAN pairing with a translated port, enter `hostname:port` or `[IPv6]:port` directly in Add computer.

There is no automatic internet relay, external VPN dependency, STUN/TURN service, router reconfiguration, or CGNAT bypass. With CGNAT and no reachable IPv6, direct inbound WAN access needs an alternative routed connection. Setup does not open a Public-profile firewall rule.

## Wake-on-LAN

Configure the remote machine's BIOS/UEFI wake support and its Ethernet adapter's power-management settings. Wired Ethernet is recommended. Whether wake works from sleep, hibernation or shutdown depends on the hardware, BIOS, driver, Windows Fast Startup and retained network power. A machine disconnected from electricity cannot wake. Wi-Fi wake is not assumed.

In **Connection settings**, verify the Ethernet adapter MAC and enter its subnet broadcast (for example `192.168.1.255` only if that is the correct broadcast for your subnet). The automatically detected MAC is a convenience; check it against the physical Ethernet adapter.

For WAN wake, select an **online paired computer on the target LAN** as the wake relay. The controller sends it an authenticated request to transmit a local magic packet. At least that relay or a suitable router must remain online. Sending a packet does not verify wake success; the target must become reachable afterward.

## Hardware sensors

If `sensors\LibreHardwareMonitorLib.dll`, or its `runtimes\win-x64\lib\net8.0` equivalent, is present, the app uses the bundled LibreHardwareMonitor 0.9.6 provider and its dependencies. It reads available temperatures, fans, clocks, power and load. Some sensor drivers require administrator privileges; the installed service runs as LocalSystem. Firmware and Windows driver restrictions can still make readings unavailable. Unsupported values are displayed as N/A.

NVIDIA GPU temperatures, utilization and power also have a direct NVML fallback using the installed NVIDIA driver. No generic CPU temperature is invented from Windows ACPI zones.

To obtain or refresh the optional provider from source, install a .NET 8+ SDK and run from the Source folder:

```powershell
dotnet publish .\sensor-provider\SensorProvider.csproj -c Release -o .\dist\RemoteControl\sensors
```

Keep the complete resulting sensors folder. Reinstall / repair remote-PC mode after adding or updating it so the installed copy receives the files.

## Current scope and limits

- Live CPU, RAM, uptime, disk capacity and network throughput; available hardware sensors.
- Browse local drives; upload/download files; create folders; move or rename files and directories on the same volume. Existing files are not overwritten by upload. Transfers stream to temporary files, then rename on completion. Maximum upload request is 16 GiB. Cross-volume moves, deletion and synchronization are not included in this build.
- View live processes, end selected processes, and request program launches in the signed-in desktop. Inaccessible process details are omitted. A launch acknowledgment confirms the request was queued; check the desktop for results.
- JPEG desktop frames up to 1920 pixels wide, covering the combined monitors, with selectable targets of 5, 10, 15, 30, 45 or 60 FPS; actual speed depends on capture time, encoding and the connection. This is an initial direct desktop implementation, not an integration with another remote desktop product. Mouse, keyboard, drag, scrolling, text injection, full screen and Task Manager shortcut are supported.
- One controller desktop lease per PC. F11 toggles full screen; Ctrl+Alt+Esc releases input. Windows key shortcuts can be intercepted locally by Windows; use the toolbar Windows-key button as needed. View-only mode still receives desktop frames.
- Windows lock/login screens, UAC secure desktop are outside this build's desktop support. No audio, automatic clipboard sync or Ctrl+Alt+Delete injection.
- Restart / shutdown requests have a 30-second cancellation window and do not use a forced-close flag. Unsaved applications may block shutdown. **Cancel shutdown** requests Windows abort the pending action.
- Pairing is locally revocable. Controller tokens use Windows DPAPI for the current user. If you move the controller configuration to a different Windows account, pair again.
- Device names and network addresses are disclosed by LAN discovery. The service does not expose files, stats or controls to unpaired callers.
- Local administrator users can access service identity data. Agent configuration is deliberately excluded from remote file browsing/downloads.

## Diagnostics and source

Remote logs: `%ProgramData%\WhitteLabs\RemoteControl\activity.log` and `error.log`. Controller errors: `%LocalAppData%\WhitteLabs\RemoteControl\error.log`. Do not share `agent.json`, `identity.pfx`, invitations or controller configuration.

Source code is available in the separate source ZIP. `Build.ps1 -WithSensors` creates a self-contained Windows x64 build. The current script uses cached .NET 8.0.11 runtime packs to permit offline builds in this development environment; refresh the runtime version and SDK before a long-term deployment.

## Sharing

See SHARING.md for the recipient setup walkthrough. Share the complete Windows x64 app ZIP; source code is packaged separately. The app has in-app setup and Setup.ps1, with Install-Remote-Access.cmd as a double-click launcher. There is no separate MSI or Setup.exe.

## Window size and shortcuts

Drag a window edge to resize, use the title-bar maximize button, or press F11 for full screen (Escape restores it). The initial window fits your display and Windows scaling. Small windows provide scrolling so controls stay accessible. Click the small **Create desktop shortcut** icon beside **Open with Windows** in the sidebar to add RCbyWL to your Windows desktop, including redirected OneDrive desktops. Keep the app folder at that location afterward.

The custom title bar stays above the scrolling content. Drag it to move the app, double-click it to maximize or restore, and use its top-right minimize, maximize and close buttons. Startup bounds are clamped to the current monitor work area, including Windows display scaling and monitors with negative coordinates.

## Reboot recovery and simpler LAN pairing

Upgrade both PCs to 0.2.6. On the remote PC, run Install / update access once to update the boot service and companion. The background service keeps retrying after startup errors and opens its network listener before hardware sensor initialization. The controller retries offline PCs and can recover their changed LAN addresses while retaining the pinned certificate and credentials. Starting the controller window alone does not install the remote access service.

For the first LAN pairing, generate a pairing code on the remote PC. On the main PC choose Find on local network, select the PC, enter its 8-digit code and compare its displayed certificate with the remote PC before confirming. No email or invitation-file transfer is needed. After initial pairing, reboots do not require a new code. Discovery sends directed broadcasts through active adapters and uses a bounded TCP fallback on nearby IPv4 /24 ranges. Guest Wi-Fi isolation and network firewall restrictions can still block LAN reachability.

## Desktop reply fix and sensor view in 0.2.6

The desktop companion now receives the JSON response needed to start capture. If an older installed service shows an empty-JSON error and a black desktop, extract the updated App folder on that PC and run **Install / update access** once. This replaces the service and restarts the companion; existing pairing is preserved. Update the controller App folder too.

The LAN pairing field shows all eight digits without clipping. Hardware readings are in the dedicated **Sensors** tab, with room for at least five complete rows and scrolling for the rest.


## Input recovery, Task Manager and frame rate

Update both PCs, then run **Install / update access** on the side PC once. Current setup registers the signed-in user's desktop companion with the highest rights available to that account. Administrator accounts can then control elevated apps such as Task Manager. Standard accounts retain their standard rights. UAC secure prompts, locked desktops and Windows sign-in remain outside this build.

The **Task Manager** toolbar button asks the companion to open Task Manager directly. Leaving the viewer releases held keys and mouse buttons. Returning restores input automatically. **Reconnect input** clears pending input, releases stale modifiers, creates a fresh input connection and restores control mode. **Release input** switches to view only; Ctrl+Alt+Esc does the same. Video continues while input is released. Each viewer has a separate session so a delayed disconnect from an older window cannot disconnect its replacement.

Choose **Target FPS** in the desktop toolbar. Available targets are 5, 10, 15, 30, 45 and 60; default 15. The footer shows actual received frames per second. This is a target, not a guarantee. Higher targets consume more CPU and network bandwidth. CPU load/temperature, GPU load/temperature, RAM and VRAM appear in a compact block inside the desktop window and on Overview. Missing sensor readings show N/A; VRAM uses the GPU's memory readings rather than estimating from system RAM.

## Laptop lid on charger

In the desktop toolbar, choose **Laptop lid**, then **Keep running on charger** and Save. This changes only the active power plan's plugged-in lid action to Do nothing. It persists after restart. Battery lid behavior is preserved. The same dialog can restore the original value saved for that power plan. Changing power plans may require enabling the option for the newly selected plan.

During active desktop sharing, the companion also refreshes the Windows display/system idle timers. This does not override locking, secure prompts or a user-requested sleep. A laptop's firmware or GPU may disable its internal display when the lid closes even if Windows remains awake. If capture is blank in that situation, reopen the lid or connect an external display; this build does not install a virtual display driver.

## Shared PC notes

The **Notes** tab after Sensors stores up to 8,000 characters on the selected remote PC. Use **Save notes** to commit and **Reload notes** to fetch current text. Approved controllers share the same notes. On the side PC, open **Set up this PC > Notes for this PC** to read or edit them locally. Notes remain with that PC's existing installation and survive restarts/updates. Controller drafts are retained while switching PCs within the open app. Conflicting saves are rejected so one side cannot silently overwrite the other's newer text. Unsaved drafts are not a replacement for Save notes.

After updating, test opening Task Manager, typing/clicking in it, Alt+Tab, Windows key, Send text, leaving/returning to the viewer, Release/Reconnect input, closing/reopening the viewer, and changing FPS. Test lid behavior while the laptop is plugged in. Windows/GPU behavior needs a real side-PC check; the packaged app contains no developer test reports.


## Experimental GPU capture and H.264 streaming

The selector is **5, 10, 15, 30, 45, 60 FPS**. At 5/10/15 the viewer uses the existing JPEG path. At 30/45/60 it tries a persistent encrypted H.264 stream, using DXGI GPU desktop capture where available. Unsupported/multiple-display layouts use GDI capture for the same video stream. Encoding and decoding currently use Windows' built-in native CPU H.264 transforms; this version does not claim hardware video encoding. No codec download, extra network port, external account or API key is required.

The footer identifies GPU/GDI capture and H.264 versus JPEG, and shows actual received FPS. The selected number is a target; CPU, display and network limits can reduce it. Video frames are scaled to fit within 1920 by 1080, preserving the combined desktop's aspect ratio. The older JPEG capture path is retained.

**Compatibility (JPEG)** forces the previous path, capped at 30 FPS. If video initialization, decoding or transport fails, the viewer automatically falls back to JPEG at up to 30 FPS. Changing the rate or toggling compatibility off retries video. Update both PCs and run Install / update access on the side PC once before trying the new mode. Secure Windows prompts and locked desktops remain unsupported.


## Controller protection (0.2.7)

Open Settings on the main PC. Basic protection preserves all features. Advanced protection keeps uncompressed safe-pixel desktop viewing/control (up to 720p / 15 FPS) and status/notes, while disabling transfers, program/process/power actions and LAN scanning. Enable it on the controller you want protected, not only on the side PC. See SECURITY.md.

For Advanced desktop, update both PCs to 0.2.7 and run Install / update access once on the side PC. Existing pairing is kept.
