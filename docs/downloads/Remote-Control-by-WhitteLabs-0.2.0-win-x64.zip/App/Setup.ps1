param([switch]$Uninstall)
$ErrorActionPreference = 'Stop'
$serviceName = 'WhitteLabsRemoteControl'
$installRoot = Join-Path $env:ProgramFiles 'WhitteLabs\RemoteControl'
$dataRoot = Join-Path $env:ProgramData 'WhitteLabs\RemoteControl'
$taskName = 'WhitteLabs Remote Desktop Companion'
function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run setup as administrator.' }
}
function Stop-RemoteService {
    $svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -ne 'Stopped') { Stop-Service -Name $serviceName -Force; $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30)) }
    # Stop only the installed desktop companion, never unrelated RemoteControl processes.
    Get-CimInstance Win32_Process -Filter "Name='RemoteControl.exe'" | Where-Object {
        $_.ExecutablePath -eq (Join-Path $installRoot 'RemoteControl.exe') -and $_.CommandLine -match '(?:^|\s)--helper(?:\s|$)'
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}
try {
    Assert-Admin
    Stop-RemoteService
    if ($Uninstall) {
        if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) { & sc.exe delete $serviceName | Out-Null; if ($LASTEXITCODE -ne 0) { throw 'Could not remove the Windows service.' } }
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        Remove-NetFirewallRule -Name 'WhitteLabs-RC-TLS','WhitteLabs-RC-Discovery' -ErrorAction SilentlyContinue
        Write-Host 'Remote-PC mode removed. Pairing data and installed files were retained. No remote listener will start at boot.' -ForegroundColor Green
    }
    else {
        $source = [IO.Path]::GetFullPath($PSScriptRoot)
        $target = [IO.Path]::GetFullPath($installRoot)
        New-Item -ItemType Directory -Path $installRoot,$dataRoot -Force | Out-Null
        if ($source -ne $target) {
            if (-not (Test-Path -LiteralPath (Join-Path $source 'RemoteControl.exe'))) { throw 'Extract the full release ZIP and run Setup.ps1 beside RemoteControl.exe.' }
            Get-ChildItem -LiteralPath $source -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $installRoot -Recurse -Force }
        }
        $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        $acl = [Security.AccessControl.DirectorySecurity]::new()
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($account in @('S-1-5-18','S-1-5-32-544',$sid)) {
            $id = [Security.Principal.SecurityIdentifier]::new($account)
            $rule = [Security.AccessControl.FileSystemAccessRule]::new($id,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
            $acl.AddAccessRule($rule)
        }
        Set-Acl -LiteralPath $dataRoot -AclObject $acl
        $exe = Join-Path $installRoot 'RemoteControl.exe'
        & $exe --initialize
        if ($LASTEXITCODE -ne 0) { throw 'Agent initialization failed. See the app error log.' }
        if (-not (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)) {
            New-Service -Name $serviceName -BinaryPathName ('"' + $exe + '" --service') -DisplayName 'Remote Control by WhitteLabs' -StartupType Automatic -Description 'Approved-device management over encrypted direct connections.' | Out-Null
        }
        Set-Service -Name $serviceName -StartupType Automatic
        & sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/15000/restart/60000 | Out-Null
        Remove-NetFirewallRule -Name 'WhitteLabs-RC-TLS','WhitteLabs-RC-Discovery' -ErrorAction SilentlyContinue
        New-NetFirewallRule -Name 'WhitteLabs-RC-TLS' -DisplayName 'WhitteLabs Remote Control (TLS)' -Direction Inbound -Action Allow -Program $exe -Protocol TCP -LocalPort 48170 -Profile Private,Domain | Out-Null
        New-NetFirewallRule -Name 'WhitteLabs-RC-Discovery' -DisplayName 'WhitteLabs Remote Control (LAN discovery)' -Direction Inbound -Action Allow -Program $exe -Protocol UDP -LocalPort 48171 -RemoteAddress LocalSubnet -Profile Private,Domain | Out-Null
        $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $action = New-ScheduledTaskAction -Execute $exe -Argument '--helper'
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
        Start-Service -Name $serviceName
        Start-ScheduledTask -TaskName $taskName
        Write-Host "Installed. Service starts at boot; desktop companion starts when $user signs in." -ForegroundColor Green
        Write-Host 'Return to the app, choose Set up this PC, and generate an invitation.'
    }
}
catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
Write-Host 'Press Enter to close.'
Read-Host | Out-Null
