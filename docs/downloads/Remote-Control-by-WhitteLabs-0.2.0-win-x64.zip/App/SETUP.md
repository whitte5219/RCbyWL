# Remote Control by WhitteLabs

Version 0.2.0 · Windows 10 / 11 x64 · personal test build

## First test

1. Extract the complete ZIP. Keep every file in the `App` folder together.
2. On your main PC, open `App\RemoteControl.exe`.
3. Copy the same App folder to each remote PC. Open the app there and choose **Set up this PC → Install / update access**. Approve Windows elevation. The PowerShell setup window reports success or an error.
4. On the remote PC, click **Generate invitation**, then **Copy invitation**.
5. On the main PC, click **Add computer**. Paste the invitation and enter the remote PC's IPv4 address. The invitation includes a pinned TLS certificate, expires in five minutes, and works once.
6. Select the paired PC. Test telemetry, files, processes, then **Open desktop**.

There are no subscriptions, external accounts, API keys, analytics, or external servers. Keys and credentials are created and handled internally. Possession of an invitation permits full management: copy it directly between your own PCs.

## Startup and installation

The controller is portable. Its **Start controller with Windows** checkbox is optional and applies to your Windows account; keep the app at the same path if enabled.

Remote-PC setup installs files under `C:\Program Files\WhitteLabs\RemoteControl`, stores its identity under `%ProgramData%\WhitteLabs\RemoteControl`, and creates an automatic LocalSystem Windows service. This grants approved controllers system-level file and process management. A separate, visibly indicated tray companion runs at logon for the account that installed it. Use your normal Windows administrator account to install. If you elevate using a different administrator's credentials, the companion task and pairing-data permissions belong to that account.

The service starts before login. Desktop access becomes available after that user signs in. The tray menu can pause desktop viewing and input or exit the companion. Pausing desktop access does not disable the management service; revoke controllers or uninstall remote-PC mode to remove management access.

**Uninstall remote-PC mode** removes the service, scheduled companion task, and app firewall rules. It retains installed files and identity data so reinstall preserves pairing. To reset the identity completely, first uninstall, close the app, then manually remove its ProgramData folder locally; every controller must then pair again.

## LAN and WLAN

Default management port: **TCP 48170 (TLS)**. Local discovery: **UDP 48171**. Setup adds inbound rules only on Private and Domain network profiles. Discovery stays on the local subnet. Guest Wi-Fi, client isolation, Public profiles, firewalls, and VLAN routing can block access. Manual IP pairing works when discovery broadcasts are blocked but TCP is reachable.

## WAN

The app accepts a reachable hostname, IPv4, or IPv6 address. Configure a network path yourself: a routed private VPN you host, reachable IPv6 with restricted firewall access, or an explicit TCP port-forward. Set the endpoint in **Connection settings**. Certificate pinning remains active regardless of address changes. A public forwarded port may differ from the agent port: use the TCP port field after pairing. Initial pairing can be done on LAN first; WAN pairing with a translated port needs the invitation's `port` to match, so LAN pairing is recommended before leaving home.

There is no automatic internet relay, external VPN dependency, STUN/TURN service, router reconfiguration, or CGNAT bypass. With CGNAT and no reachable IPv6, direct inbound WAN access needs an alternative routed connection. Setup does not open a Public-profile firewall rule.

## Wake-on-LAN

Configure the remote machine's BIOS/UEFI wake support and its Ethernet adapter's power-management settings. Wired Ethernet is recommended. Whether wake works from sleep, hibernation or shutdown depends on the hardware, BIOS, driver, Windows Fast Startup and retained network power. A machine disconnected from electricity cannot wake. Wi-Fi wake is not assumed.

In **Connection settings**, verify the Ethernet adapter MAC and enter its subnet broadcast (for example `192.168.1.255` only if that is the correct broadcast for your subnet). The automatically detected MAC is a convenience; check it against the physical Ethernet adapter.

For WAN wake, select an **online paired computer on the target LAN** as the wake relay. The controller sends it an authenticated request to transmit a local magic packet. At least that relay or a suitable router must remain online. Sending a packet does not verify wake success; the target must become reachable afterward.

## Hardware sensors

If `sensors\LibreHardwareMonitorLib.dll`, or its `runtimes\win-x64\lib\net8.0` equivalent, is present, the app uses the bundled LibreHardwareMonitor 0.9.6 provider and its dependencies. It reads available temperatures, fans, clocks, power and load. Some sensor drivers require administrator privileges; the installed service runs as LocalSystem. Firmware and Windows driver restrictions can still make readings unavailable. Unsupported values are displayed as N/A.

NVIDIA GPU temperatures, utilization and power also have a direct NVML fallback using the installed NVIDIA driver. No generic CPU temperature is invented from Windows ACPI zones.

To obtain or refresh the optional provider from source, install a .NET 8+ SDK and run from the Source folder:

```powershell
dotnet publish .\sensor-provider\SensorProvider.csproj -c Release -o .\dist\RemoteControl\sensors
```

Keep the complete resulting sensors folder. Reinstall / repair remote-PC mode after adding or updating it so the installed copy receives the files.

## Current scope and limits

- Live CPU, RAM, uptime, disk capacity and network throughput; available hardware sensors.
- Browse local drives; upload/download files; create folders; move or rename files and directories on the same volume. Existing files are not overwritten by upload. Transfers stream to temporary files, then rename on completion. Maximum upload request is 16 GiB. Cross-volume moves, deletion and synchronization are not included in this build.
- View live processes, end selected processes, and request program launches in the signed-in desktop. Inaccessible process details are omitted. A launch acknowledgment confirms the request was queued; check the desktop for results.
- JPEG desktop frames up to 1920 pixels wide, covering the combined monitors, typically around 5–8 updates per second depending on capture time and connection. This is an initial direct desktop implementation, not an integration with another remote desktop product. Mouse, keyboard, drag, scrolling, text injection, full screen and Task Manager shortcut are supported.
- One controller desktop lease per PC. F11 toggles full screen; Ctrl+Alt+Esc releases input. Windows key shortcuts can be intercepted locally by Windows; use the toolbar Windows-key button as needed. View-only mode still receives desktop frames.
- Windows lock/login screens, UAC secure desktop and higher-integrity windows are outside this build's desktop support. No audio, automatic clipboard sync or Ctrl+Alt+Delete injection.
- Restart / shutdown requests have a 30-second cancellation window and do not use a forced-close flag. Unsaved applications may block shutdown. **Cancel shutdown** requests Windows abort the pending action.
- Pairing is locally revocable. Controller tokens use Windows DPAPI for the current user. If you move the controller configuration to a different Windows account, pair again.
- Device names and network addresses are disclosed by LAN discovery. The service does not expose files, stats or controls to unpaired callers.
- Local administrator users can access service identity data. Agent configuration is deliberately excluded from remote file browsing/downloads.

## Diagnostics and source

Remote logs: `%ProgramData%\WhitteLabs\RemoteControl\activity.log` and `error.log`. Controller errors: `%LocalAppData%\WhitteLabs\RemoteControl\error.log`. Do not share `agent.json`, `identity.pfx`, invitations or controller configuration.

Source code is available in the separate source ZIP. `Build.ps1 -WithSensors` creates a self-contained Windows x64 build. The current script uses cached .NET 8.0.11 runtime packs to permit offline builds in this development environment; refresh the runtime version and SDK before a long-term deployment.

`RemoteControl.exe --self-test` runs an isolated integration test using a temporary identity and loopback TLS server, then writes `self-test-results.txt` beside the executable. Run that from a writable extracted folder, not Program Files. It does not install services, change firewall rules, send real remote input or perform power actions.

This build's loopback checks cover authentication, certificate mismatch, one-use invitations, file integrity, overwrite prevention, credential-path protection, process enumeration, desktop leases, pause behavior and revocation. Multi-PC LAN/WAN, installed-service startup, actual input/video and wake still need your hardware test.


## Sharing

See SHARING.md for the recipient setup walkthrough. Share the complete Windows x64 app ZIP; source code is packaged separately. The app has in-app setup and Setup.ps1, with Install-Remote-Access.cmd as a double-click launcher. There is no separate MSI or Setup.exe.
