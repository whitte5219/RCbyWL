@echo off
set "WHITTELABS_SETUP_DIR=%~dp0"
powershell.exe -NoProfile -Command "Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File ' + [char]34 + (Join-Path $env:WHITTELABS_SETUP_DIR 'Setup.ps1') + [char]34) -WorkingDirectory $env:WHITTELABS_SETUP_DIR"
if errorlevel 1 pause
