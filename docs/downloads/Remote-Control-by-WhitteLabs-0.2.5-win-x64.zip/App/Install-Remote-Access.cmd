@echo off
set "WHITTELABS_SETUP_DIR=%~dp0"
powershell.exe -NoProfile -Command "$rcSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value; Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File ' + [char]34 + (Join-Path $env:WHITTELABS_SETUP_DIR 'Setup.ps1') + [char]34 + ' -InteractiveUserSid ' + $rcSid) -WorkingDirectory $env:WHITTELABS_SETUP_DIR -Wait"
if errorlevel 1 pause
