@echo off
start "" /d "%~dp0" "%~dp0RemoteControl.exe"
