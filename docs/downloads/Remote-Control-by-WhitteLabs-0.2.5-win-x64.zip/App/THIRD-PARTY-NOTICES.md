# Third-party components

Remote Control by WhitteLabs uses the Microsoft .NET / ASP.NET Core / Windows Desktop runtime, including System.ServiceProcess.ServiceController. The runtime's original license and third-party notice files are included with the portable application. Microsoft .NET is distributed under the MIT license with additional component notices. Source: https://github.com/dotnet

## Optional sensor provider

LibreHardwareMonitorLib 0.9.6 is distributed unmodified, under the Mozilla Public License 2.0. Copyright belongs to the LibreHardwareMonitor contributors and other original authors. You can obtain the corresponding source, license and third-party licenses at:

- https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6
- https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/blob/v0.9.6/LICENSE
- https://www.mozilla.org/MPL/2.0/
- https://www.nuget.org/packages/LibreHardwareMonitorLib/0.9.6

The optional provider's NuGet dependency graph also includes DiskInfoToolkit, BlackSharp.Core, HidSharp, RAMSPDToolkit-NDD, Mono.Posix.NETStandard, System.IO.Ports, System.Management, System.CodeDom and System.Threading.AccessControl. Their package license metadata and license copies are included under `sensors\licenses` when bundled. No changes are made to these third-party assemblies. Availability of each sensor depends on hardware and driver support.

NVIDIA NVML is dynamically accessed from the NVIDIA driver already installed on the host. No NVIDIA binaries are redistributed.
