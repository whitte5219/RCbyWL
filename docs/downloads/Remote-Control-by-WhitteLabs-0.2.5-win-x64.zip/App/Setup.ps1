param([switch]$Uninstall, [switch]$NonInteractive, [string]$OperationId, [string]$InteractiveUserSid)
$ErrorActionPreference = 'Stop'
$serviceName = 'WhitteLabsRemoteControl'
$programRoot = if (${env:ProgramW6432}) { ${env:ProgramW6432} } else { $env:ProgramFiles }
$installRoot = Join-Path $programRoot 'WhitteLabs\RemoteControl'
$dataRoot = Join-Path $env:ProgramData 'WhitteLabs\RemoteControl'
$taskName = 'WhitteLabs Remote Desktop Companion'
$exitCode = 0
$resultMessage = ''
if ($OperationId -and $OperationId -notmatch '^[a-fA-F0-9]{32}$') { throw 'Invalid setup operation.' }
function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run setup as administrator.' }
}
function Stop-RemoteService {
    $svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -ne 'Stopped') { Stop-Service -Name $serviceName -Force; $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30)) }
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    # Stop only the installed companion, never controllers in other folders.
    Get-CimInstance Win32_Process -Filter "Name='RemoteControl.exe'" | Where-Object {
        $_.ExecutablePath -eq (Join-Path $installRoot 'RemoteControl.exe') -and $_.CommandLine -match '(?:^|\s)--helper(?:\s|$)'
    } | ForEach-Object {
        $companion = Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue
        if ($companion) { $companion | Stop-Process -Force; $companion.WaitForExit(10000) | Out-Null }
    }
}
try {
    Assert-Admin
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This download requires 64-bit Windows. Open Settings > System > About to check System type.' }
    $source = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
    $target = [IO.Path]::GetFullPath($installRoot).TrimEnd('\')
    if (-not $Uninstall -and -not (Test-Path -LiteralPath (Join-Path $source 'RemoteControl.exe'))) { throw 'Extract the entire ZIP first. Setup.ps1 must be beside RemoteControl.exe in the App folder.' }
    Stop-RemoteService
    if ($Uninstall) {
        if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) { & sc.exe delete $serviceName | Out-Null; if ($LASTEXITCODE -ne 0) { throw 'Could not remove the Windows service.' } }
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        Remove-NetFirewallRule -Name 'WhitteLabs-RC-TLS','WhitteLabs-RC-Discovery' -ErrorAction SilentlyContinue
        $resultMessage = 'Remote access removed. Pairing data and installed files were kept.'
    }
    else {
        New-Item -ItemType Directory -Path $installRoot,$dataRoot -Force | Out-Null
        if ($source -ne $target) {
            # An older installed controller can lock the files even after the service stops.
            Get-Process -Name RemoteControl -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq (Join-Path $installRoot 'RemoteControl.exe') } | ForEach-Object {
                if (-not $_.HasExited) {
                    $_.CloseMainWindow() | Out-Null
                    if (-not $_.WaitForExit(10000)) { throw 'Close the installed Remote Control app, then try Install / update access again.' }
                }
            }
            Get-ChildItem -LiteralPath $source -Force | Where-Object {
                $_.Name -notmatch '^(self-test-|offline-test-|restart-test-|ui-preview|render-error|WhitteLabs-RC-test-)' -and $_.Name -notmatch '^(VERIFICATION\.txt|verification\.txt)$' -and $_.Extension -ne '.pdb'
            } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $installRoot -Recurse -Force }
        }
        $sid = if ($InteractiveUserSid) { ([Security.Principal.SecurityIdentifier]::new($InteractiveUserSid)).Value } else { [Security.Principal.WindowsIdentity]::GetCurrent().User.Value }
        $acl = [Security.AccessControl.DirectorySecurity]::new()
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($account in @('S-1-5-18','S-1-5-32-544',$sid)) {
            $id = [Security.Principal.SecurityIdentifier]::new($account)
            $rule = [Security.AccessControl.FileSystemAccessRule]::new($id,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
            $acl.AddAccessRule($rule)
        }
        Set-Acl -LiteralPath $dataRoot -AclObject $acl
        $exe = Join-Path $installRoot 'RemoteControl.exe'
        $initialization = Start-Process -FilePath $exe -ArgumentList '--initialize' -WorkingDirectory $installRoot -WindowStyle Hidden -Wait -PassThru
        if ($initialization.ExitCode -ne 0) { throw 'Agent initialization failed. Check %LocalAppData%\WhitteLabs\RemoteControl\error.log.' }
        if (-not (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)) {
            New-Service -Name $serviceName -BinaryPathName ('"' + $exe + '" --service') -DisplayName 'Remote Control by WhitteLabs' -StartupType Automatic -Description 'Approved-device management over encrypted direct connections.' | Out-Null
        }
        else {
            # Use a structured Windows call: Windows PowerShell 5.1 can strip the
            # embedded path quotes when forwarding this value to sc.exe.
            $installedService = Get-CimInstance -ClassName Win32_Service -Filter "Name='$serviceName'"
            if (-not $installedService) { throw 'The installed service could not be read. Restart Windows, then run setup again.' }
            $change = Invoke-CimMethod -InputObject $installedService -MethodName Change -Arguments @{ PathName = ('"' + $exe + '" --service') }
            if ($change.ReturnValue -ne 0) { throw ('Windows could not update the service configuration (code ' + $change.ReturnValue + '). Run setup as administrator. If the service was just removed, restart Windows first.') }
        }
        Set-Service -Name $serviceName -StartupType Automatic
        & sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/15000/restart/60000 | Out-Null
        $agentConfig = Get-Content -LiteralPath (Join-Path $dataRoot 'agent.json') -Raw | ConvertFrom-Json
        $port = [int]$agentConfig.port
        if ($port -lt 1 -or $port -gt 65534) { throw 'The configured agent port is invalid.' }
        Remove-NetFirewallRule -Name 'WhitteLabs-RC-TLS','WhitteLabs-RC-Discovery' -ErrorAction SilentlyContinue
        New-NetFirewallRule -Name 'WhitteLabs-RC-TLS' -DisplayName 'WhitteLabs Remote Control (TLS)' -Direction Inbound -Action Allow -Program $exe -Protocol TCP -LocalPort $port -Profile Private,Domain | Out-Null
        New-NetFirewallRule -Name 'WhitteLabs-RC-Discovery' -DisplayName 'WhitteLabs Remote Control (LAN discovery)' -Direction Inbound -Action Allow -Program $exe -Protocol UDP -LocalPort 48171 -RemoteAddress LocalSubnet -Profile Private,Domain | Out-Null
        $user = ([Security.Principal.SecurityIdentifier]::new($sid)).Translate([Security.Principal.NTAccount]).Value
        $action = New-ScheduledTaskAction -Execute $exe -Argument '--helper'
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        # Administrator-approved setup uses the user's highest available rights for
        # Task Manager and elevated windows, inside that user's signed-in desktop.
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
        Start-Service -Name $serviceName
        (Get-Service -Name $serviceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
        $listening = $false
        $deadline = [DateTime]::UtcNow.AddSeconds(30)
        do {
            $probe = New-Object Net.Sockets.TcpClient
            try { $listening = $probe.ConnectAsync('127.0.0.1', $port).Wait(1000) -and $probe.Connected } catch { } finally { $probe.Dispose() }
            if (-not $listening) { Start-Sleep -Milliseconds 250 }
        } while (-not $listening -and [DateTime]::UtcNow -lt $deadline)
        if (-not $listening) { throw 'The service did not open its network port. Check %ProgramData%\WhitteLabs\RemoteControl\error.log. Another app may already use the port.' }
        Start-ScheduledTask -TaskName $taskName
        $resultMessage = 'Remote access is ready. Generate an invitation to pair your main PC.'
        if (Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object NetworkCategory -eq 'Public') {
            $resultMessage += ' If pairing is blocked on your trusted home network, set that connection to Private in Windows Settings > Network & internet.'
        }
    }
}
catch { $exitCode = 1; $resultMessage = $_.Exception.Message }
if ($OperationId) {
    try {
        New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
        @{ success = ($exitCode -eq 0); message = $resultMessage } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dataRoot ('setup-' + $OperationId + '.json')) -Encoding UTF8
    } catch { }
}
if (-not $NonInteractive) {
    $color = if ($exitCode -eq 0) { 'Green' } else { 'Red' }
    Write-Host $resultMessage -ForegroundColor $color
    Read-Host 'Press Enter to close' | Out-Null
}
exit $exitCode
